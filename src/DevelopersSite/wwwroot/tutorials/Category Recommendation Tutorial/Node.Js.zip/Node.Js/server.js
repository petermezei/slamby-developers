var slambySdk = require('slamby-sdk');
var client = new slambySdk.ApiClient();
var express = require('express');
var app = express();
var fs = require('fs');

console.log("Server URL is localhost:1337");

var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

app.get('/', function(req,res){
    fs.readFile('index.html',function (err, data){
        res.writeHead(200, {'Content-Type': 'text/html','Content-Length':data.length});
        res.write(data);
        res.end();
    });
});

app.post('/getcategories', function(req,res){
    client.basePath = "https://api.slamby.com/imsold/";
    client.defaultHeaders = {
        "Authorization": "Slamby imsold43947"
    };

    //client.defaultHeaders["X-DataSet"] = "profession_test";
    //Service ID: 0693e3dc-4bcc-431f-9ee5-e01a37ab36bb 

    var apiInstance = new slambySdk.ClassifierServiceApi(client);

    var id = "0693e3dc-4bcc-431f-9ee5-e01a37ab36bb"; // String | 

    var request = new slambySdk.ClassifierRecommendationRequest();
    request.text = req.body.text;
    request.count = "50";
    request.needTagInResult = true;

    var opts = { 
    'request': request
    };

    apiInstance.recommendService(id, opts).then(function(data) {
        res.send(data);
    }, function(error) {
    console.error(error);
    });
});

app.listen(1337);